# ==============================================
# Lab Assignment 4 - Time Complexity (Q7–Q9)
# ==============================================
import time

# Hint:
# Try plotting the time complexity data with matplotlib to visualize growth trends
# Will help in identifying the expected time complexity class

# ---------- Q7 ----------
def func1(n):
    s = 0
    for _ in range(n):
        j = 1
        while j * j <= n:
            s += 1
            j += 1
    return s

def analyze_func1():
    """
    TODO:
    - Pick at least 3 n values
    - Measure runtime for each n and store in a dict {n: time}
    - Return (dict, "Estimated Complexity: O(?)")
    """
    # Example skeleton (replace with your own n's):
    # times = {}
    # for n in [ ... ]:
    #     Evalute func1(n) and measure time taken
    # return times, "Estimated Complexity: O(?)"
    times={}
    for n in [10,50,100]:
        start_time=time.perf_counter()
        func1(n)
        end_time=time.perf_counter()
        time_of_performance=end_time-start_time
        times[n]=time_of_performance
    return times,"Estimated Complexity: O(n^1.5)"
    pass



# ---------- Q8 ----------
def func2(n):
    for _ in range(n):
        for _ in range(n):
            k = 1
            while k < n:
                k *= 2

def analyze_func2():
    """
    TODO: same pattern as analyze_func1
    """
    times={}
    for n in [10,25,50]:
        start_time=time.perf_counter()
        func2(n)
        end_time=time.perf_counter()
        time_of_performance=end_time-start_time
        times[n]=time_of_performance
    return times,"Estimated Complexity: O(n^2(log(n)))"
    pass


# ---------- Q9 ----------
def func3(n):
    if n <= 1:
        return 1
    return func3(n-1) + func3(n-1)

def analyze_func3():
    """
    TODO: same pattern as analyze_func1
    """
    times={}
    for n in [10,15,20]:
        start_time=time.perf_counter()
        func3(n)
        end_time=time.perf_counter()
        time_of_performance=end_time-start_time
        times[n]=time_of_performance
    return times,"Estimated Complexity: O(2^n)"
    pass