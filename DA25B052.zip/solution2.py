# ==============================================
# Lab Assignment 4 - String Manipulation (Q10–Q11)
# ==============================================

# Q10: Palindrome Rearrangement Checker
def palindrome_checker(s):
    # TODO:
    # - Return "Yes" if string can be rearranged into a palindrome
    # - Return "No" otherwise
    # - Return "input invalid" for empty or non-string
    if type(s) != str or s=="" or s.strip() == "":
        return "input invalid"
    else:
        alphs=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
        s=s.lower()
        no_of_letters=[]
        for alph in alphs:
            if alph in s:
                num=s.count(alph)
                no_of_letters.append(num)
            else:
                pass
        even_odd=[i%2 for i in no_of_letters]
        if even_odd.count(1)<=1:
            return "Yes"
        else:
            return "No"
    pass



# Q11: String Rotation Validator
def rotation_checker(s1, s2):
    # TODO:
    # - Return True if s2 is a rotation of s1
    # - Return False otherwise
    # - Return "input invalid" if inputs are not strings or lengths differ
    if type(s1) != str or s1=="" or s1.strip() == "" or type(s2) != str or s2=="" or s2.strip() == "" or len(s1)!=len(s2):
        return "input invalid"
    else:
        if s1 in s2+s2 and s2 in s1+s1:
            return True
        else:
            return False
    pass
